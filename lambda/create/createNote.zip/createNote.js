const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.NOTES_TABLE;

exports.handler = async (event) => {
  const { title, content } = JSON.parse(event.body);

  if (!title || !content) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "title and content are required" }),
    };
  }

  const note = {
    id: uuidv4(),
    title,
    content,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  await dynamo
    .put({
      TableName: TABLE_NAME,
      Item: note,
    })
    .promise();

  return {
    statusCode: 201,
    body: JSON.stringify(note),
  };
};

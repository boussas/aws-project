const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.NOTES_TABLE;

exports.handler = async (event) => {
  const id = event.pathParameters.id;
  const { title, content } = JSON.parse(event.body);

  if (!title && !content) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: "At least one of title or content is required",
      }),
    };
  }

  const updateExpressions = [];
  const expressionAttributeValues = {};

  if (title) {
    updateExpressions.push("title = :title");
    expressionAttributeValues[":title"] = title;
  }
  if (content) {
    updateExpressions.push("content = :content");
    expressionAttributeValues[":content"] = content;
  }
  updateExpressions.push("updatedAt = :updatedAt");
  expressionAttributeValues[":updatedAt"] = new Date().toISOString();

  const params = {
    TableName: TABLE_NAME,
    Key: { id },
    UpdateExpression: "SET " + updateExpressions.join(", "),
    ExpressionAttributeValues: expressionAttributeValues,
    ReturnValues: "ALL_NEW",
  };

  const result = await dynamo.update(params).promise();

  return {
    statusCode: 200,
    body: JSON.stringify(result.Attributes),
  };
};

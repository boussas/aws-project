const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.NOTES_TABLE;

exports.handler = async () => {
  const data = await dynamo.scan({ TableName: TABLE_NAME }).promise();

  return {
    statusCode: 200,
    body: JSON.stringify(data.Items),
  };
};

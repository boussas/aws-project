const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.NOTES_TABLE;

exports.handler = async (event) => {
  const id = event.pathParameters.id;

  if (!id) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "id is required" }),
    };
  }

  await dynamo
    .delete({
      TableName: TABLE_NAME,
      Key: { id },
    })
    .promise();

  return {
    statusCode: 204,
  };
};
